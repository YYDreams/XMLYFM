//
//  FMConstUrl.swift
//  XMYLFM
//
//  Created by flowerflower on 2018/11/1.
//  Copyright © 2018年 flowerflower. All rights reserved.
//

import UIKit

import Foundation

/**********************************************/
//配置Host
let MAIN_URL_6 = "http://180.153.255.6"
//
let MAIN_URL = "http://mobile.ximalaya.com"





//http://180.153.255.6/passport/token/login
let kPassportTokenLogin = "/passport/token/login"


//POST http://mobile.ximalaya.com/passport-sign-mobile/v3/signin/password
//     http://mobile.ximalaya.com/passport-sign-mobile/v3/signin/password
//密码登录
let kSigninPasswordUrl = "/passport-sign-mobile/v3/signin/password"


//POST http://hybrid.ximalaya.com/api/passport/password/security/reset/mobile/ajaxnew
//修改密码
let kPasswordSecurityResetUrl = "/api/passport/password/security/reset/mobile/ajaxnew"



let kMobileUrl = "/mobile/homePage/"


//http://180.153.255.6/mobile/v2/point/query
//查询积分
let kMobilePointQueryUrl = "/mobile/v2/point/query"


