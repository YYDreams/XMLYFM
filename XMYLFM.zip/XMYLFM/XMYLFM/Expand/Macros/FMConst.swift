//
//  FMConst.swift
//  XMYLFM
//
//  Created by flowerflower on 2018/11/1.
//  Copyright © 2018年 flowerflower. All rights reserved.
//

import UIKit

/***************************** 常量 *******************************/

let screenW: CGFloat = UIScreen.main.bounds.width
let screenH: CGFloat = UIScreen.main.bounds.height

/** appKey */
let appKey = "1700900454"
/** appSecret */
let appSecret = "a3933c2adf181050c275c28957a97cf2"
/** 回调的url */
let redirect_uri = "http://www.sina.com.cn"
/** 账号 */
let userId = "18673556376"
/** 密码 */
let passwd = "flowerflower"




/***************************** Notification *******************************/

//login Success
let kLoginSuccessNotification  = "kLoginSuccessNotification"
// select Photo
let kSelectPhotoNotification  = "kSelectPhotoNotification"

//delete Photo
let kDeletePhotoNotification  = "kDeletePhotoNotification"

// Home didSelectItemAt
let kHomePhotoSelectItemNotification  = "kHomePhotoSelectItemNotification"

//Home Photo Index Key
let kHomeShowPhotoBrowserIndexKey  = "kHomeShowPhotoBrowserIndexKey"

//Home Photo Url Key
let kHomeShowPhotoBrowserUrlKey  = "kHomeShowPhotoBrowserUrlKey"


